//Trinh Tran

package cpsc2150.extendedTicTacToe;
import java.util.*;

public class GameScreen {

    private static IGameBoard gameBoard;

    /**
     * main method controls flow of program
     * @param args command-line arguments
     * @pre none
     * @post game is playable and no bugs
     */
    public static void main(String[] args){
        char player = ' ';
        int count = 0;
        int userRow;
        int userColumn;
        Scanner input = new Scanner(System.in);
        String userInput;
        boolean spaceIsValid = false;
        boolean userWantsToPlay = true;

        gameBoard = new GameBoard();
        System.out.println(gameBoard.toString());

        //runs as long as user wants to play the game
        while (userWantsToPlay) {
            //even is for X and odd is for O, allow players to rotate turns
            if (count % 2 == 0) player = 'X';
            else player = 'O';
            count++;

            spaceIsValid = false;
            //will prompt user for input as long as their move is not available
            while (!spaceIsValid) {
                System.out.println("Player " + player + " Please enter your ROW");
                userInput = input.nextLine();
                userRow = Integer.parseInt(userInput);

                System.out.println("Player " + player + " Please enter your COLUMN");
                userInput = input.nextLine();
                userColumn = Integer.parseInt(userInput);

                BoardPosition pos = new BoardPosition(userRow, userColumn);
                spaceIsValid = gameBoard.checkSpace(pos);

                if (!spaceIsValid) System.out.println(gameBoard.toString());
                //when the user input a valid space, place the user's marker and check for a winner or a draw
                if (spaceIsValid) {
                    gameBoard.placeMarker(pos, player);
                    if(gameBoard.checkForWinner(pos)) {
                        System.out.println("Player " + player + " wins!");
                        System.out.println(gameBoard.toString());
                        System.out.println("Would you like to play again? Y/N");
                        userInput = input.nextLine();
                        if (userInput.toLowerCase().equals("y")) {
                            gameBoard = new GameBoard();
                            count = 0;
                        }
                        else {
                            userWantsToPlay = false;
                            break;
                        }
                    }
                    else if (gameBoard.checkForDraw()) {
                        System.out.println("It's a draw!");
                        System.out.println(gameBoard.toString());
                        System.out.println("Would you like to play again? Y/N");
                        userInput = input.nextLine();
                        if (userInput.toLowerCase().equals("y")) {
                            gameBoard = new GameBoard();
                            count = 0;
                        }
                        else {
                            userWantsToPlay = false;
                            break;
                        }
                    }
                    System.out.println(gameBoard.toString());
                }
                else System.out.println("That space is unavailable, please pick again");
            }
        }

    }
}
