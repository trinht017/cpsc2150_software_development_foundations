//Trinh Tran

package cpsc2150.extendedTicTacToe;

import java.util.*;

public class GameBoard extends AbsGameBoard implements IGameBoard {
    /**
     * GameBoard class contains the game board
     * @invariant gameBoard is a numRows x numColumns 2-dimensional array of characters, 0,0 is top left corner
     * @invariant numRows = MAX_ROW
     * @invariant numColumns = MAX_COLUMN
     * @invariant numToWin = NUM_TO_WIN
     *
     * correspondence numRows = NUM_OF_ROWS
     * correspondence numColumns = NUM_OF_COLUMNS
     * correspondence numToWin = NUM_TO_WIN
     */
    private char [][] gameBoard;
    private int numRows;
    private int numColumns;
    private int numToWin;

    /**
     * Constructor
     * @pre none
     * @post gameBoard is a numRows x numColumns 2-d array of characters
     *       all spaces will be filled with ' ' (a single blank space character)
     *       0,0 is top left corner
     *
     *       numRows = MAX_ROW
     *       numColumns = MAX_COLUMN
     *       numToWin = NUM_TO_WIN
     */
    public GameBoard() {
        numRows = MAX_ROW;
        numColumns = MAX_COLUMN;
        numToWin = NUM_TO_WIN;

        gameBoard = new char[numRows][numColumns];
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numColumns; j++) {
                gameBoard[i][j] = ' ';
            }
        }
    }

    @Override
    public int getNumRows() {
        return numRows;
    }

    @Override
    public int getNumColumns() {
        return numColumns;
    }

    @Override
    public int getNumToWin() {
        return numToWin;
    }

    @Override
    public void placeMarker(BoardPosition marker, char player) {
        int row = marker.getRow();
        int column = marker.getColumn();

        gameBoard[row][column] = player;
    }

    @Override
    public char whatsAtPos(BoardPosition pos) {
        return gameBoard[pos.getRow()][pos.getColumn()];
    }

}
